/**
*	GameTree ADT
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the GameTree ADT which is a
	general game tree.  The GameTree is built using
	TNode ADTs.  A GameTree object consists of a
	"root" field which refers to a TNode object
	which has a "data" field and "parent",
	"child" and "sibling" references, and a
	"level" value.
	
	YOU NEED TO MAKE CHANGES TO THIS FILE!
*/


public class GameTree implements GameTreeInterface
{
	//finals
	private final boolean TRACING=true;				// do we want to see trace output?

	// properties
	private TNode root;								// the node at the top of the tree


	public GameTree()
	/*
		Constructor method 1.
		Pre-condition: none
		Post-condition: the GameTree object's "root" field is null
		Informally: creates an empty tree
	*/
	{
		trace("GameTree: constructor starts");
		
		root=null;
		
		trace("GameTree: constructor ends");
	}


	public GameTree(Object o, int l)
	/*
		Constructor method 2.
		Pre-condition: none
		Post-condition: the GameTree object's "root" field refers
						to a new TNode object containing the
						parameter value (o) of level with
						parameter value (l) with a null parent,
						null child, and null sibling
		Informally: create a tree of a single node (i.e. a leaf)
					with the node and level value provided on the
					parameter list
	*/
	{
		trace("GameTree: constructor starts");
		
		root=new TNode(o,l);
		
		trace("GameTree: constructor ends");
	}
	
	
	public GameTree(Object o,int l,GameTree p)
	/*
		Constructor method 3.
		Pre-condition: none
		Post-condition: the GameTree object's "root" field refers
						to a new TNode object containing the
						parameter value (o) with "parent" field
						of the parameter value (p), "level" field
						of the parameter value (l), null child,
						and null sibling
		Informally: create a tree of a single node (i.e. a leaf)
					with the node and level value provided on the
					parameter list and the given parent
	*/
	{
		trace("GameTree: constructor starts");
		
		root=new TNode(o,l);
		root.setParent(p.root);
		
		trace("GameTree: constructor ends");
	}
	
	
	public boolean isEmpty()
	/*
		Emptiness test.
		Pre-condition: none
		Post-condition: true is returned if the GameTree object is
						empty, false is returned otherwise
		Informally: indicate if the GameTree contains no nodes
	*/
	{
		trace("isEmpty: isEmpty starts and ends");
		
		return (root == null);
	}


	public Object getGrid() throws EmptyGameTreeException
	/*
		Get method for "root" instance variable's data value.
		Pre-condition: none
		Post-condition: the value of the GameTree object's data
						field is returned
		Informally: return the value within the root node,
					throw an exception if the tree is empty
	*/
	{
		trace("getGrid: getGrid starts");
		
		if (isEmpty())
		{
			trace("getGrid: empty game tree");
			throw new EmptyGameTreeException();
		}

		trace("getGrid: getGrid ends");
		return root.getData();
	}
	
	
	public int getLevel() throws EmptyGameTreeException
	/*
		Get method for "root" instance variable's level value.
		Pre-condition: none
		Post-condition: the value of the GameTree object's data
						field's level is returned
		Informally: return the level value within the root node,
					throw an exception if the tree is empty
	*/
	{
		trace("getLevel: getLevel starts");

COMPLETE ME!

		trace("getLevel: getLevel ends");
	}
	
	
	public GameTree getParent() throws EmptyGameTreeException
	/*
		Get method for "root" instance variable's parent value.
		Pre-condition: none
		Post-condition: the value of the GameTree object's parent
						field is returned in a newly
						constructed GameTree object
		Informally: return the GameTree object's parent, throw an
						exception if the tree is empty
	*/
	{
		GameTree r;
		
		trace("getParent: getParent starts");
		
		if (isEmpty())
		{
			trace("getParent: empty game tree");
			throw new EmptyGameTreeException();
  		}
  		
		r=new GameTree();
		r.root=root.getParent();

		trace("getParent: getParent ends");
		return r;
	}


	public GameTree getChild() throws EmptyGameTreeException
	/*
		Get method for "root" instance variable's child value.
		Pre-condition: none
		Post-condition: the value of the GameTree object's child
						field is returned in a newly
						constructed GameTree object
		Informally: return the GameTree object's child, throw
						an exception if the tree is empty
	*/
	{
		trace("getChild: getChild starts");

COMPLETE ME!

		trace("getChild: getChild ends");
	}


	public GameTree getSibling() throws EmptyGameTreeException
	/*
		Get method for "root" instance variable's sibling value.
		Pre-condition: none
		Post-condition: the value of the GameTree object's sibling
						field is returned in a newly
						constructed GameTree object
		Informally: return the GameTree object's sibling, throw
						an exception if the tree is empty
	*/
	{
		trace("getSibling: getSibling starts");

COMPLETE ME!

		trace("getSibling: getSibling ends");
	}


	public void setGrid(Object o) throws EmptyGameTreeException
	/*
		Set method for "root" instance variable's data field.
		Pre-condition: none
		Post-condition: the TNode object's data field is altered to
						hold the given (o) value
		Informally: store the given value in the root node of the
					GameTree object, throw an exception if the tree is
					empty
	*/
	{
		trace("setGrid: setGrid starts");
		
		if (isEmpty())
		{
			trace("setGrid: empty game tree");
			throw new EmptyGameTreeException();
		}
		
		root.setData(o);
		
		trace("setGrid: setGrid ends");
	}
	
	
	public void setLevel(int l) throws EmptyGameTreeException
	/*
		Set method for "root" instance variable's level field.
		Pre-condition: none
		Post-condition: the TNode object's level field is altered
						to hold the given (l) value
		Informally: assign the given value as the level of the
					GameTree object, throw an exception if the tree is
					empty
	*/
	{
		trace("setLevel: setLevel starts");

COMPLETE ME!

		trace("setLevel: setLevel ends");
	}
	
	
	public void setParent(GameTree t) throws EmptyGameTreeException
	/*
		Set method for "root" instance variable's parent field.
		Pre-condition: none
		Post-condition: the TNode object's parent field is altered
						to hold the given (t) value
		Informally: assign the given value as the parent of the
					GameTree object, throw an exception if the tree is
					empty
	*/
	{
		trace("setParent: setParent starts");
		
		if (isEmpty())
		{
			trace("setParent: empty game tree");
			throw new EmptyGameTreeException();
  		}
  		
		root.setParent(t.root);
		
		trace("setParent: setParent ends");
	}
	
	
	public void setChild(GameTree t) throws EmptyGameTreeException
	/*
		Set method for "root" instance variable's child field.
		Pre-condition: none
		Post-condition: the TNode object's child field is altered
						to hold the given (t) value
		Informally: assign the given value as the child of the
					GameTree object, throw an exception if the tree is
					empty
	*/
	{
		trace("setChild: setChild starts");

COMPLETE ME!

		trace("setChild: setChild ends");
	}
	
	
	public void setSibling(GameTree t) throws EmptyGameTreeException
	/*
		Set method for "root" instance variable's sibling field.
		Pre-condition: none
		Post-condition: the TNode object's sibling field is altered
						to hold the given (t) value
		Informally: assign the given value as the sibling of the
					GameTree object, throw an exception if the tree is
					empty
	*/
	{
		trace("setSibling: setSibling starts");

COMPLETE ME!

		trace("setSibling: setSibling ends");
	}
	
	
	public void generateLevelDF(Stack s,Player curr, Player opp)
	/*
		Generate the next level of the tree
		Pre-condition: the given tree is defined, the given stack
					   is defined, and the given player represents
					   the current player
		Post-condition: an additional level of possible moves has
						been added to the given game tree and each
						tree node of the new level also has been
						pushed onto the stack.  Each move is for
						the given player if the level number of the
						level is even, and for its opponent
						otherwise.  Each grid in the new level has
						a value calculated from the opponent's
						perspective
		Informally: generate the next level of the game tree
	*/
	{
		trace("generateLevelDF: generateLevelDF starts");

COMPLETE ME!

		trace("generateLevelDF: generateLevelDF ends");
	}
	
	
	public void buildGameDF(Grid b, Stack s, Player curr, Player opp, int d)
	/*
		Generate the game tree in a depth-first manner
		Pre-condition: the given tree is defined, if the given tree
					   is empty then the given grid is defined, the
					   given stack is defined, the given player
					   represents the current player, and the given
					   int value represents the desired depth of the
					   tree
		Post-condition: if the given tree is empty then it is replaced
						with a new tree at level 0 consisting of the
						given board (and this new tree is pushed onto
						the stack).  If the given tree isn't empty and
						it is not already deep enough, if there are
						children, then these are traversed and all
						siblings are pushed onto the stack.  If (when)
						there are no children an additional level of
						possible moves is added to the given game tree
						and each tree node of the new level also is
						pushed onto the stack.  Finally, the next tree
						is determined by removing the top of the stack
						and the process continues until the stack is
						empty
		Informally: generate the game tree from the current point
					in a depth-first manner until it is "d" levels
					deep
	*/
	{
		trace("buildGameDF: buildGameDF starts");

COMPLETE ME!

		trace("buildGameDF: buildGameDF ends");
	}
	
	
	public void generateLevelBF(Queue q,Player curr,Player opp)
	/*
		Generate the next level of the tree
		Pre-condition: the given tree is defined, the given queue
					   is defined, and the given player represents
					   the current player
		Post-condition: an additional level of possible moves has
						been added to the given game tree and each
						tree node of the new level also has been
						added onto the queue.  Each move is for
						the given player if the level number of the
						level is even, and for its opponent
						otherwise.  Each grid in the new level has
						a value calculated from the opponent's
						perspective
		Informally: generate the next level of the game tree
	*/
	{
		trace("generateLevelBF: generateLevelBF starts");

COMPLETE ME!

		trace("generateLevelBF: generateLevelBF ends");
	}
	
	
	public void buildGameBF(Grid b, Queue q, Player curr, Player opp, int d)
	/*
		Generate the game tree in a breadth-first manner
		Pre-condition: the given tree is defined, if the given tree
					   is empty then the given grid is defined, the
					   given queue is defined, the given player
					   represents the current player, and the given
					   int value represents the desired depth of the
					   tree
		Post-condition: if the given tree is empty then it is replaced
						with a new tree at level 0 consisting of the
						given board (and this new tree is added onto
						the queue).  If the given tree isn't empty and
						it is not already deep enough, if there are
						children, then these are traversed and all
						siblings are added onto the queue.  If (when)
						there are no children an additional level of
						possible moves is added to the given game tree
						and each tree node of the new level also is
						added onto the queue.  Finally, the next tree
						is determined by removing the front of the
						queue and the process continues until the
						queue is empty
		Informally: generate the game tree from the current point
					in a depth-first manner until it is "d" levels
					deep
	*/
	{
		trace("buildGameBF: buildGameBF starts");

COMPLETE ME!

		trace("buildGameBF: buildGameBF starts");
	}				


	public void adjustLevel()
	/*
		Adjust the level numbers of the tree
		Pre-condition: the given tree is defined
		Post-condition: all level numbers in the tree are reduced
						by one
		Informally: decrement the level number of all nodes in
					the game tree
	*/
	{
		trace("adjustLevel: adjustLevel starts");
		
  		if (! isEmpty()) {
    		getChild().adjustLevel();
    		getSibling().adjustLevel();
    		trace("adjustLevel: setting level to " + (getLevel()-1));
    		setLevel(getLevel()-1);
  		}
  		
		trace("adjustLevel: adjustLevel ends");
	}


	public int chooseBest()
	/*
		Find the value of the best move in the tree
		Pre-condition: the given tree is defined
		Post-condition: the value of the best move that can
						be made is returned
		Informally: examine the next alternate moves and return
					the value of the best one
	*/
	{
  		int i;
  		int v;
  		GameTree t;
  
		trace("chooseBest: chooseBest starts");
		
  		v=((Grid)getGrid()).getWorth();
  		trace("chooseBest: starting with a worth of " + v);
  		
  		t=this;
  		while (! t.getSibling().isEmpty())
  		{
    		t=t.getSibling();
    		i=((Grid)t.getGrid()).getWorth();
    		trace("chooseBest: considering a worth of " + i);
    		
   			if (t.getLevel() % 2 != 0)
   			{ 
       			if (i > v)
       			{
          			v=i;
          		}
      		}
      		else
      		{
        		if (i < v)
        		{
          			v=i;
          		}
      		}
  		}
  		trace("chooseBest: best worth is " + v);

		trace("chooseBest: chooseBest ends");
  		return v;
	}


	public void traverse()
	/*
		Walk over the tree locating the best move
		Pre-condition: the given tree is defined
		Post-condition: the grids of all nodes in the tree have
						up-to-date values
		Informally: filter the best move values from the leaf
					nodes up to the root
	*/
	{
  		int v;
  		GameTree t;
  		Grid b;

		trace("traverse: traverse starts");
		
  		if (! isEmpty())
  		{
    		if (! getChild().isEmpty())
    		{
      			t=getChild();
      			while (! t.isEmpty())
      			{
        			t.traverse();
        			t=t.getSibling();
      			}
      			trace("traverse: siblings traversed");
      			v=getChild().chooseBest();
      			b=(Grid)getGrid();
      			b.setWorth(v);
      			setGrid(b);
      			trace("traverse: worth of " + v + " set");
    		}
  		}
  		
		trace("traverse: traverse ends");
	}


	public void findBest(int v)
	/*
		Find the best move in the tree for the computer
		Pre-condition: the given tree is defined
		Post-condition: the tree is adjusted so that the current
						state is overriden by the game tree with
						the best next move as its root and all
						level numbers are decremented accordingly
		Informally: computer has a turn!
	*/
	{
  		GameTree t;
  
		trace("findBest: findBest starts");
		
  		t=getChild();
    	while (((Grid)t.getGrid()).getWorth() != v)
      	{
      		trace("findBest: not this move, trying sibling");
      		t=t.getSibling();
  		}
  		
  		trace("findBest: found it; cutting off remaining siblings and adjusting");
        t.setSibling(new GameTree());
    	t.adjustLevel();
    	
    	root=t.root;
    	
		trace("findBest: findBest ends");
	}


	public void findMove()
	/*
		Find the nominated move in the tree (located at the top and as one child)
		Pre-condition: the given tree is defined
		Post-condition: the tree is adjusted so that the current
						state is overriden by the game tree with
						the grid as specified in the parameter as
						its root and all level numbers are
						decremented accordingly
		Informally: find the move the human just made!
	*/
	{
	  	GameTree t;

		trace("findMove: findMove starts");
		
	  	t=getChild();
	  	if (! t.isEmpty())
	  	{
	    	while ((! t.isEmpty()) && (! ((Grid) t.getGrid()).equals((Grid) getGrid())))
	      	{
	      		trace("findMove: not this move, trying sibling");
	      		t=t.getSibling();
      		}
      		
	    	if (t.isEmpty())
	    	{
	    		trace("findMove: not there, creating empty tree as sentinel");
				t=new GameTree();
	    	}
	    	else
	    	{
	    		trace("findMove: found it, cutting off remaining siblings and adjusting");
	      		t.setSibling(new GameTree());
	      		t.setParent(new GameTree());
	      		t.adjustLevel();
	    	}
	  	}
	  	
		root=t.root;
		trace("findMove: findMove ends");
	}
	

	public String rootNodeToString()
	/*
		String conversion for root node value
		Pre-condition: none
		Post-condition: a String object is returned consisting of the
					String representation of the value within the
					root node, followed by " " or "<>" if the GameTree
					object is the empty tree
		Informally: produce a String representation of the tree's root
					node
	*/
	{
		String s="";

		trace("rootNodeToString: rootNodeToString starts");
		
		if (isEmpty())
		{
			return "<>";
		}
		else
		{
			s=s+getGrid().toString() + " ";
		}

		trace("rootNodeToString: rootNodeToString ends");
		return s;
	}
	
	
	public String toString()
	/*
		String conversion for tree
		Pre-condition: none
		Post-condition: a String object is returned consisting of the
					String representation of all items in the GameTree,
					from top to bottom in depth-first order, separated by
					" " and contained within "<" and ">"
		Informally: produce a String representation of the Stack
	*/
	{
		GameTree c;
		String s="";

		trace("toString: toString starts");
		
		if (isEmpty())
		{
			trace("toString: toString ends");
			return "<>";
		}
		else
		{
			s=s.concat(rootNodeToString());
			c=getChild();
			if (! c.isEmpty())
			{
				s=s+(c.toString());
			}
			c=getSibling();
			if (! c.isEmpty())
			{
				s=s+(c.toString());
			}
		}

		trace("toString: toString ends");
		return s;
	}


	public void trace(String s)
	/*
		Provide trace output.
		Pre-condition: none
		Post-condition: if trace output is desired then the given String
						parameter is shown on the console
		Informally: show the given message for tracing purposes
	*/
	{
		if (TRACING)
		{
			System.out.println("GameTree: " + s);
		}
	}
}
