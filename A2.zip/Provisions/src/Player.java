/**
*	Player ADT
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Player ADT which represents
	the concept of a game participant.
	A Player consists of a coloured symbol.
	
	This file is complete.
*/

import java.awt.*;


public class Player implements PlayerInterface, Comparable
{
	//finals
	private final boolean TRACING=true;				// do we want to see trace output?

	// properties
	private Symbol symbol;	// the colour of the symbol
	
	
	public Player(Color c)
	/*
		Constructor method.
		Pre-condition: none
		Post-condition: the Color value is defined and valid
		Informally: intialises the instance variable of the newly
					created Player object to have a symbol of the
					specified colour
	*/
	{
      	trace("Player: Constructor starts");

		symbol=new Symbol();
		symbol.setColour(c);

      	trace("Player: Constructor starts");
	}
	
	
	public void setSymbol(Symbol s)
	/*
		Set method for "symbol" instance variable.
		Pre-condition: the symbol (s) is valid
		Post-condition: the Player object's symbol is altered to hold
						the given (s) value
		Informally: assign the value of the parameter to the Player
					object's symbol instance variable
	*/
	{
      	trace("setSymbol: setSymbol starts");

		symbol=s;

      	trace("setSymbol: setSymbol ends");
	}
	
	
	public Symbol getSymbol()
	/*
		Get method for "symbol" instance variable.
		Pre-condition: none
		Post-condition: the Player object's symbol is returned
		Informally: examine the Player object's symbol instance
						variable returning its value
	*/
	{
      	trace("getSymbol: getSymbol starts and ends");

		return symbol;
	}
	
	
	public int compareTo(Object o)
	/*
		Test equality of player.
		Pre-condition: parameter is a validly defined Player value
		Post-condition: 0 is returned if current player and given value
						possess identical symbols, +/-1 is returned
						otherwise
		Informally: check whether the given player has the same symbol as
						the current player value
	*/
	{
		Player p=(Player) o;
		
      	trace("compareTo: compareTo starts and ends");

		return (symbol.compareTo(p.getSymbol()));
	}
	
	
	public Player opponent(Player p1, Player p2)
	/*
		Find the opponent
		Pre-condition: the parameter is a defined player object
		Post-condition: the opposite player to the current player is
						returned
		Informally: find the opponent to the current player
	*/
	{
      	trace("opponent: opponent starts");

		if (this.equals(p1))
		{
	   		trace("opponent: opponent ends (P2)");
			return p2;
		}
		else
		{
	   		trace("opponent: opponent ends (P1)");
			return p1;
		}
	}
	
	
	public boolean equals(Player p)
	/*
		Test equality of player symbols.
		Pre-condition: parameter is a validly defined Player value
		Post-condition: true is returned if current player and given value
						possess identical symbols, false is returned
						otherwise
		Informally: check whether the given player has the same symbol as
						the current player
	*/
	{
      	trace("equals: equals starts and ends");

		return (this.compareTo(p) == 0);
	}


	public Object clone()
	/*
		Copy the player.
		Pre-condition: none
		Post-condition: a clone of the current object is created
		Informally: create a copy of the player
	*/
	{
		Player p=new Player(getSymbol().getColour());

      	trace("clone: clone starts and ends");
		
		return p;
	}


	public void trace(String s)
	/*
		Provide trace output.
		Pre-condition: none
		Post-condition: if trace output is desired then the given String
						parameter is shown on the console
		Informally: show the given message for tracing purposes
	*/
	{
		if (TRACING)
		{
			System.out.println("Player: " + s);
		}
	}
}