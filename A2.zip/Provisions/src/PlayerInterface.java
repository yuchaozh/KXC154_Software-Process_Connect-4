/**
*	Player ADT Interface
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Player ADT which represents
	the concept of a game participant.
	A Player consists of a coloured symbol.
	
	This file is complete.
*/


public interface PlayerInterface
{
	//public Player(Color c);
	public void setSymbol(Symbol s);
	public Symbol getSymbol();
	public int compareTo(Object o);
	public Player opponent(Player p1,Player p2);
	public boolean equals(Player p);
	public Object clone();
}
