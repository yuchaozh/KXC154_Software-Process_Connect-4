/**
*	Square ADT
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Square ADT which represents
	a physical space within a grid.  A Square in a
	grid consists of a location, and a symbol.
	
	YOU NEED TO MAKE CHANGES TO THIS FILE!
*/

import java.awt.*;


public class Square implements SquareInterface, Cloneable
{	
	//finals
	private final boolean TRACING=true;				// do we want to see trace output?

	// properties
	private Location loc;		// the location of the current square within the grid
	private Symbol symbol;		// the symbol of the current square
	
	
	public Square(Location l)
	/*
		Constructor method 1.
		Pre-condition: the given location value is defined
		Post-condition: the Square object's "loc" field is the value
						given, its "symbol" field is the 'empty' (default) symbol
		Informally: creates an empty square at the given location
	*/
	{
      	trace("Square: Constructor starts");

COMPLETE ME!

      	trace("Square: Constructor ends");
	}
	
	
	public Square(Location l,Symbol s)
	/*
		Constructor method 2.
		Pre-condition: the given location and symbol values are defined
		Post-condition: the Square object's "loc" field is the value
						given, and its "symbol" field is assigned
						the given value
		Informally: creates a square at the given location with the given
						symbol
	*/
	{
      	trace("Square: Constructor starts");

COMPLETE ME!

      	trace("Square: Constructor ends");
	}
	
	
	public Object clone()
	/*
		Pre-condition: the current Square object is validly defined
		Post-condition: the Square object is copied
		Informally: copy the current Square
	*/
	{
      	trace("clone: clone starts");

COMPLETE ME!

      	trace("clone: clone ends");
	}
	
	
	public Location getLocation()
	/*
		Get method for "loc" instance variable.
		Pre-condition: none
		Post-condition: the value of the Square object's
						location field is returned
		Informally: return the current square's location
	*/
	{
      	trace("getLocation: getLocation starts and ends");

COMPLETE ME!

	}
	
	
	public void setLocation(Location l)
	/*
		Set method for "loc" instance variable.
		Pre-condition: the given Location value is defined and
					   valid within the enclosing grid
		Post-condition: the value of the Square object's loc
						field is altered to contain the given
						Location value
		Informally: update the Square object's Location to the
					given value
	*/
	{
      	trace("setLocation: setLocation ends");

COMPLETE ME!

      	trace("setLocation: setLocation ends");
	}
	
	
	public Symbol getSymbol()
	/*
		Get method for "symbol" instance variable.
		Pre-condition: none
		Post-condition: the value of the Square object's
						symbol field is returned
		Informally: return the current square's symbol
	*/
	{
      	trace("getSymbol: getSymbol starts and ends");

COMPLETE ME!

	}
	
	
	public void setSymbol(Symbol s)
	/*
		Set method for "symbol" instance variable.
		Pre-condition: none
		Post-condition: the value of the Square object's symbol
						field is altered to contain the given
						Symbol value
		Informally: update the Square object's Symbol to the
					given value
	*/
	{
      	trace("setSymbol: setSymbol ends");

COMPLETE ME!

      	trace("setSymbol: setSymbol ends");
	}
	
	
	public boolean isEmpty()
	/*
		Check whether square is occupied.
		Pre-condition: none
		Post-condition: true is returned if the value of the Square
						object's symbol field is returned
		Informally: return whether the current square is occupied
	*/
	{
		Symbol empty;
		
      	trace("isEmpty: isEmpty starts");

		empty=new Symbol();

      	trace("isEmpty: isEmpty ends");
		return (empty.compareTo(getSymbol()) == 0);
	}
	
	
	public void showSquare(Display s,int w)
	/*
		Pre-condition: the Screen parameter is correctly defined
		Post-condition: the screen representation of the Square
						object is displayed on the given Screen at
						the position related to its location using
						the Square object's symbol and the given
						width
		Informally: display the current square
	*/
	{
		int x,y;
		Graphics g;
		
      	trace("toString: toString starts");
		
		x=(loc.getColumn()-1)*(w+5) + 5;
		y=70 + (loc.getRow()-1)*(w+5);

		g=s.getGraphics();
		g.fillRect(x,y,5,w+10);
		g.fillRect(x,y,w+10,5);
		g.fillRect(x+w+5,y,5,w+10);
		g.fillRect(x,y+w+5,w+10,5);
		
		trace("toString: square is " + toString());	
		symbol.showSymbol(s,loc,w);
		
      	trace("toString: toString ends");
	}
	
	
	public String toString()
	/*
		Pre-condition: none
		Post-condition: a String representation of the current
						Square is returned
		Informally: find the String equivalent of the current
					square
	*/
	{
      	trace("toString: toString starts and ends");
      	
		return symbol.toString();
	}


	public void trace(String s)
	/*
		Provide trace output.
		Pre-condition: none
		Post-condition: if trace output is desired then the given String
						parameter is shown on the console
		Informally: show the given message for tracing purposes
	*/
	{
		if (TRACING)
		{
			System.out.println("Square: " + s);
		}
	}
}
