/**
*	Display ADT
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Display ADT which represents
	the computer screen.  Internally, the screen is
	represented by a graphics context.
	
	This file is complete.
*/

import java.awt.*;


public class Display implements DisplayInterface
{
	//finals
	private final boolean TRACING=true;				// do we want to see trace output?

	// properties
	private Graphics graphics;						// the window on which to draw etc.

	
	public Display()
	/*
		Constructor method.
		Pre-condition: none
		Post-condition: the Display object's "graphics" instance
						variable is set to null
		Informally: intialises the graphics window to null
	*/
	{
		trace("Display: constructor begins");
		
		graphics=null;
		
		trace("Display: constructor ends");
	}
	
	
	public void setGraphics(Graphics g)
	/*
		Set method for "graphics" instance variable.
		Pre-condition: the graphics context (g) is a valid window
		Post-condition: the Display object's graphics instance variable
						is altered to hold the given (g) value
		Informally: assign a graphics window value to the object
	*/
	{
		trace("setGraphics: setGraphics starts");
		
		graphics=g;
		
		trace("setGraphics: setGraphics ends");
	}
	
	
	public Graphics getGraphics()
	/*
		Get method for "graphics" instance variable.
		Pre-condition: none
		Post-condition: the Display object's graphics value is
						returned
		Informally: examine the Graphics object's window component
					instance variable returning its value
	*/
	{
		trace("getGraphics: getGraphics starts and ends");
		return graphics;
	}


	public void trace(String s)
	/*
		Provide trace output.
		Pre-condition: none
		Post-condition: if trace output is desired then the given String
						parameter is shown on the console
		Informally: show the given message for tracing purposes
	*/
	{
		if (TRACING)
		{
			System.out.println("Display: " + s);
		}
	}
}