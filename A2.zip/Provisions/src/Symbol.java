/**
*	Symbol ADT
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Symbol ADT which represents
	pieces within the two-dimensional grid.
	A Symbol consists of a representation of a red or blue
	disc or empty.
	
	YOU NEED TO MAKE CHANGES TO THIS FILE!
*/

import java.awt.*;


public class Symbol implements SymbolInterface, Cloneable, Comparable
{
	//finals
	private final boolean TRACING=true;				// do we want to see trace output?

	// properties
	private Color colour;	// the colour of the symbol
	private boolean empty;	// whether the symbol is the empty symbol
	
	
	public Symbol()
	/*
		Constructor method.
		Pre-condition: none
		Post-condition: the Symbol object is empty and has no colour
		Informally: intialises the instance variables of the newly
					created Symbol object to have null colour and a false
	*/
	{
      	trace("Symbol: Constructor ends");

		empty=true;
		colour=Color.black;

      	trace("Symbol: Constructor ends");
	}
	
	
	public void setColour(Color c)
	/*
		Set method for "colour" instance variable.
		Pre-condition: the colour (c) is valid
		Post-condition: the Symbol object's colour is altered to hold
						the given (c) value
		Informally: assign the value of the parameter to the Symbol
					object's colour instance variable
	*/
	{
      	trace("setColour: setColour starts");

COMPLETE ME!

      	trace("setColour: setColour ends");
	}
	
	
	public void makeEmpty()
	/*
		Set method for "empty" (and "colour") instance variables.
		Pre-condition: none
		Post-condition: the Symbol object's emptiness record is
						altered to hold true and the colour is set
						to a 'non-color', e.g. black
		Informally: assign the value of true to the Symbol object's
						empty instance variable and invalidate the colour
						instance variable
	*/
	{
      	trace("makeEmpty: makeEmpty starts");

		empty=true;
		colour=Color.black;

      	trace("makeEmpty: makeEmpty ends");
	}
	
	
	public Color getColour()
	/*
		Get method for "colour" instance variable.
		Pre-condition: none
		Post-condition: the Symbol object's colour is returned
		Informally: examine the Symbol object's colour instance
						variable returning its value
	*/
	{
      	trace("getColour: getColour starts and ends");

COMPLETE ME!

	}
	
	
	public boolean isEmpty()
	/*
		Get method for "empty" instance variable.
		Pre-condition: none
		Post-condition: the Symbol object's emptiness record is returned
		Informally: examine the Symbol object's empty instance variable
						returning its value
	*/
	{
      	trace("isEmpty: isEmpty starts and ends");

COMPLETE ME!

	}
	
	
	public int compareTo(Object o)
	/*
		Test equality of symbols.
		Pre-condition: parameter is a validly defined Symbol value
		Post-condition: 0 is returned if current symbol and given value
						possess identical colours, +1 otherwise
		Informally: check whether the given symbol has the same colour as
						the current symbol value
	*/
	{
		Symbol s=(Symbol) o;
		
      	trace("compareTo: compareTo starts");

		if ((isEmpty()) && (s.isEmpty()))
  	    {
  	    	trace("compareTo: compareTo ends (0)");
			return 0;
		}
		else
		{			
			if (s.getColour().equals(getColour()))
	  	    {
	  	    	trace("compareTo: compareTo ends (0)");
				return 0;
			}
			else
	  	    {
	  	    	trace("compareTo: compareTo ends (0)");
				return 1;  // order is arbitrary
			}
		}
	}
	
	
	public boolean equals(Symbol s)
	/*
		Test equality of symbols.
		Pre-condition: parameter is a validly defined Symbol value
		Post-condition: true is returned if current symbol and given value
						possess identical colours, false otherwise
		Informally: check whether the given symbol has the same colour as
						the current symbol value
	*/
	{
      	trace("equals: equals starts and ends");

COMPLETE ME!

	}
	
	
	public Object clone()
	/*
		Clone a symbol.
		Pre-condition: none
		Post-condition: the Symbol object is copied
		Informally: copy the current Symbol
	*/
	{
		Symbol s;
		
      	trace("clone: clone starts");

		s=new Symbol();
		if (! isEmpty())
		{
			s.setColour(getColour());
		}
		
      	trace("clone: clone ends");
		return s;
	}
	
	
	public void showSymbol(Display s, Location l, int w)
	/*
		Display method for Symbol
		Pre-condition: the Screen and Location parameters are
						correctly defined and w is a positive
						integer
		Post-condition: the screen representation of the Symbol
						object is displayed on the given Screen at
						the given location in the grid using the
						Symbol object's colour to display the
						Symbol (of width w pixels)
		Informally: display the current symbol
	*/
	{
		int x, y;

      	trace("showSymbol: showSymbol starts");
		
		if (!isEmpty())
		{
		  	x=(l.getColumn()-1)*(w+5) + 10 + 3;
		  	y=75 + (l.getRow()-1)*(w+5) + 3;
		  	
		  	s.getGraphics().setColor(Color.black);
		  	s.getGraphics().fillOval(x,y,w-6,w-6);
		  	s.getGraphics().setColor(getColour());
		  	s.getGraphics().fillOval(x+2,y+2,w-10,w-10);
			s.getGraphics().setColor(Color.black);
			
 	     	trace("showSymbol: symbol is " + toString());
		}
		
      	trace("showSymbol: showSymbol ends");
	}
	
	
	public String toString()
	/*
		Pre-condition: none
		Post-condition: a String representation of the current
						Symbol is returned
		Informally: find the String equivalent of the current
					symbol ("R" for player 1/human; "B" for
					player 2/computer)
	*/
	{
      	trace("toString: toString starts");

		if (isEmpty())
      	{
      		trace("toString: toString ends (empty)");
			return " ";
		}
		else
		{
			if (getColour().equals(Color.red))
      		{
      			trace("toString: toString ends (P1)");
				return "R";
			}
			else
      		{
      			trace("toString: toString ends (P2)");
				return "B";
			}
		}
	}


	public void trace(String s)
	/*
		Provide trace output.
		Pre-condition: none
		Post-condition: if trace output is desired then the given String
						parameter is shown on the console
		Informally: show the given message for tracing purposes
	*/
	{
		if (TRACING)
		{
			System.out.println("Symbol: " + s);
		}
	}
}