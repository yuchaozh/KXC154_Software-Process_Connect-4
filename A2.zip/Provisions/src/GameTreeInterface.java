/**
*	GameTree ADT Interface
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the GameTree ADT which is a
	general game tree.  The GameTree is built using
	TNode ADTs.  A GameTree object consists of a
	"root" field which refers to a TNode object
	which has a "data" field and "parent",
	"child" and "sibling" references, and a
	"level" value.
	
	This file is complete.
*/


public interface GameTreeInterface
{
	//public GameTree();
	//public GameTree(Object o, int l);
	//public GameTree(Object o, int l, GameTree p);
	public boolean isEmpty();
	public void setGrid(Object o) throws EmptyGameTreeException;
	public Object getGrid() throws EmptyGameTreeException;
	public void setLevel(int l);
	public int getLevel();
	public void setChild(GameTree c) throws EmptyGameTreeException;
	public GameTree getChild() throws EmptyGameTreeException;
	public void setSibling(GameTree s) throws EmptyGameTreeException;
	public GameTree getSibling() throws EmptyGameTreeException;
	public void setParent(GameTree s) throws EmptyGameTreeException;
	public GameTree getParent() throws EmptyGameTreeException;
	public void generateLevelDF(Stack s,Player p1,Player p2);
	public void generateLevelBF(Queue q,Player p1,Player p2);
	public void buildGameDF(Grid g,Stack s,Player p1,Player p2,int l);
	public void buildGameBF(Grid g,Queue q,Player p1,Player p2,int l);
	public int chooseBest();
	public void findBest(int w);
//	public void replace(GameTree t) throws EmptyGameTreeException;
	public String toString();
}
