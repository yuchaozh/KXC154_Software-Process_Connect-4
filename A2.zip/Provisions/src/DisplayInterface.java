/**
*	Display ADT Interface
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Display ADT which represents
	the computer screen.  Internally, the screen is
	represented by a graphics context.
	
	This file is complete.
*/

import java.awt.*;

public interface DisplayInterface
{
	//public Display();
	public void setGraphics(Graphics g);
	public Graphics getGraphics();
}
