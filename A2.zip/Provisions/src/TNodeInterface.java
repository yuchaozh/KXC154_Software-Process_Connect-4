/**
*	Tree Node ADT Interface
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Tree Node ADT which represents
	the nodes in a doubly-linked general tree.  Tree
	nodes consist of a "data" field and three references
	to other nodes (these being the parent node ("parent"),
	the child node ("child"), and the eldest sibling node
	("sibling").
	
	This file is complete.
*/


public interface TNodeInterface
{
	//public TNode(Object o);
	//public TNode(Object o, TNode p);
	public void setData(Object o);
	public Object getData();
	public void setLevel(int l);
	public int getLevel();
	public void setParent(TNode n);
	public TNode getParent();
	public void setChild(TNode n);
	public TNode getChild();
	public void setSibling(TNode n);
	public TNode getSibling();
}
