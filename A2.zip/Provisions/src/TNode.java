/**
*	Tree Node ADT
*	@author J.R.Dermoudy
*	@version April 2011
	
	This file holds the Tree Node ADT which represents
	the nodes in a doubly-linked general tree.  Tree
	nodes consist of a "data" field, a level number
	("level"), and three references to other nodes
	(these being the parent node ("parent"), the child
	node ("child"), and the eldest sibling node
	("sibling").
	
	This file is complete.
*/


public class TNode implements TNodeInterface
{
	//finals
	private final boolean TRACING=true;				// do we want to see trace output?

	// properties
	private Object data;	// the value stored in the node
	private int level;		// the level of the current node
	private TNode parent;	// the parent node to the current node
	private TNode child;	// the eldest child node of the current node
	private TNode sibling;	// the next eldest node of the current node


	public TNode(Object o, int l)
	/*
		Constructor method 1.
		Pre-condition: none
		Post-condition: the TNode object holds the parameter value
						(o) within its "data" field, the parameter
						value (l) within its "level" field, and its
						"parent", "child", and "sibling" fields are
						null
		Informally: intialises the instance variables of the newly
					created TNode object to hold the given parameters
					and to terminate the "parent", "child", and
					"sibling" fields
	*/
	{
      	trace("TNode: Constructor ends");

		data=o;
		level=l;
		parent=null;
		child=null;
		sibling=null;

      	trace("TNode: Constructor ends");
	}


	public TNode(Object o, int l, TNode p)
	/*
		Constructor method 2.
		Pre-condition: none
		Post-condition: the TNode object holds the parameter value
						(o) within its "data" field, the parameter
						value (l) within its "level" field, the
						parameter value (p) within its "parent"
						field, and its "child", and "sibling" fields
						are null
		Informally: intialises the instance variables of the newly
					created TNode object to hold the given parameters
					and to terminate the "child" and "sibling" fields
	*/
	{
      	trace("TNode: Constructor ends");

		data=o;
		level=l;
		parent=p;
		child=null;
		sibling=null;

      	trace("TNode: Constructor ends");
	}
	
	
	public void setData(Object o)
	/*
		Set method for "data" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's data field is altered to
						hold the given (o) value
		Informally: assign the value of the parameter to the TNode
					object's "data" instance variable
	*/
	{
      	trace("setData: setData starts");

		data=o;

      	trace("setData: setData ends");
	}
	
	
	public void setParent(TNode n)
	/*
		Set method for "parent" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's parent field is altered to
						hold the given (n) value
		Informally: assign the value of the parameter to the TNode
					object's "parent" instance variable
	*/
	{
      	trace("setParent: setParent starts");

		parent=n;

      	trace("setParent: setParent ends");
	}
	
	
	public void setLevel(int l)
	/*
		Set method for "level" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's level field is altered to
						hold the given (l) value
		Informally: assign the value of the parameter to the TNode
					object's "level" instance variable
	*/
	{
      	trace("setLevel: setLevel starts");

		level=l;

      	trace("setLevel: setLevel ends");
	}
	
	
	public void setChild(TNode n)
	/*
		Set method for "child" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's child field is altered
						to hold the given (n) value
		Informally: assign the value of the parameter to the TNode
					object's "child" instance variable
	*/
	{
      	trace("setChild: setChild starts");

		child=n;

      	trace("setChild: setChild ends");
	}
	
	
	public void setSibling(TNode n)
	/*
		Set method for "sibling" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's sibling field is altered
						to hold the given (n) value
		Informally: assign the value of the parameter to the TNode
					object's "sibling" instance variable
	*/
	{
      	trace("setSibling: setSibling starts");

		sibling=n;

      	trace("setSibling: setSibling ends");
	}
	
	
	public Object getData()
	/*
		Get method for "data" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's data field is returned
		Informally: examine the TNode object's "data" instance
					variable returning its value
	*/
	{
      	trace("getData: getData starts and ends");

		return data;
	}
	
	
	public int getLevel()
	/*
		Get method for "level" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's level field is
					returned
		Informally: examine the TNode object's "level" instance
					variable returning its value
	*/
	{
      	trace("getLevel: getLevel starts and ends");

		return level;
	}
	
	
	public TNode getParent()
	/*
		Get method for "parent" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's parent field is
						returned
		Informally: examine the TNode object's "parent" instance
					variable returning its value
	*/
	{
      	trace("getParent: getParent starts and ends");

		return parent;
	}
	
	
	public TNode getChild()
	/*
		Get method for "child" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's child field is
						returned
		Informally: examine the TNode object's "child"
					instance variable returning its value
	*/
	{
      	trace("getChild: getChild starts and ends");

		return child;
	}
	
	
	public TNode getSibling()
	/*
		Get method for "sibling" instance variable.
		Pre-condition: none
		Post-condition: the TNode object's sibling field is
						returned
		Informally: examine the TNode object's "sibling"
					instance variable returning its value
	*/
	{
      	trace("getSibling: getSibling starts and ends");

		return sibling;
	}


	public void trace(String s)
	/*
		Provide trace output.
		Pre-condition: none
		Post-condition: if trace output is desired then the given String
						parameter is shown on the console
		Informally: show the given message for tracing purposes
	*/
	{
		if (TRACING)
		{
			System.out.println("TNode: " + s);
		}
	}
}
